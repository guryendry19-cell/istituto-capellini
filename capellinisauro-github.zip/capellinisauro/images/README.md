# Cartella immagini

Inserisci qui le immagini usate nel sito.

| File                  | Utilizzato in                        | Dimensioni consigliate |
|-----------------------|--------------------------------------|------------------------|
| `news-featured.jpg`   | Card notizia in evidenza (hero news) | 800 × 500 px           |

Formati supportati: `.jpg`, `.jpeg`, `.webp`, `.png`
