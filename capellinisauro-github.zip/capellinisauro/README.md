# I.I.S. Capellini–Sauro — Sito Web Redesign

Redesign del sito dell'**I.I.S. G. Capellini – N. Sauro** di La Spezia.
Progetto statico HTML/CSS/JS, pronto per GitHub Pages.

## 🚀 Come usarlo

### Opzione 1 — GitHub Pages (consigliato)

1. Carica questa cartella su un repository GitHub
2. Vai su **Settings → Pages**
3. In "Source" seleziona il branch `main` e la cartella `/ (root)`
4. Il sito sarà online all'indirizzo `https://<tuo-username>.github.io/<nome-repo>/`

### Opzione 2 — In locale

```bash
# Clona il repository
git clone https://github.com/<tuo-username>/<nome-repo>.git

# Apri index.html nel browser
open index.html
```

Nessuna dipendenza da installare. Il sito usa solo HTML, CSS e JavaScript vanilla.

## 📁 Struttura

```
capellinisauro/
├── index.html          # Pagina principale
├── css/
│   └── style.css       # Tutti gli stili
├── js/
│   └── main.js         # Menu mobile + animazioni
├── images/
│   └── news-featured.jpg  # (aggiungi qui le tue immagini)
└── README.md
```

## 🖼️ Immagini

La card notizia in evidenza cerca `images/news-featured.jpg`.
Puoi sostituirla con qualsiasi foto dell'istituto in formato JPG o WebP
(dimensioni consigliate: 800×500 px).

## 🎨 Personalizzazione

Le variabili CSS sono in cima a `css/style.css`:

```css
:root {
  --color-primary: #003d7a;   /* Blu principale */
  --color-accent:  #0077b6;   /* Blu accento    */
  --color-dark:    #0d1b3e;   /* Blu scuro      */
}
```

Cambia `--color-primary` per aggiornare il tema in tutto il sito.

## ✅ Funzionalità

- Responsive (mobile, tablet, desktop)
- Menu hamburger su mobile
- Smooth scroll sugli anchor link
- Animazione fade-in al scroll (rispetta `prefers-reduced-motion`)
- Accessibilità: landmark HTML5, `aria-label`, focus visibile
- Link diretti ai servizi ufficiali dell'istituto

## 📋 Font

- **[Syne](https://fonts.google.com/specimen/Syne)** — titoli
- **[Inter](https://fonts.google.com/specimen/Inter)** — testo corpo

Caricati da Google Fonts (CDN). Per uso offline, scarica i file e aggiorna `index.html`.

---

Sito ufficiale: [capellinisauro.edu.it](https://www.capellinisauro.edu.it)
